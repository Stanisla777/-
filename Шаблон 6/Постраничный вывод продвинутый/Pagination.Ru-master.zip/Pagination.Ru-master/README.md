RUS
=============

Решение на PHP5 для быстрого создания постраничной разбивки данных веб-приложений.

Инструкция по установке и  примеры смотрите на сайте <a href="http://www.pagination.ru">http://www.pagination.ru</a>

ENG
=============

The solution on PHP5.3 to quickly create pagination for web applications.

Installation instructions and examples, please visit <a href="http://www.pagination.ru">http://www.pagination.ru</a> with russian instructions or do <a href="http://translate.google.com/translate?sl=ru&tl=en&js=n&prev=_t&hl=en&ie=UTF-8&eotf=1&u=http%3A%2F%2Fwww.pagination.ru%2F&act=url">translate this page</a> in google ;)
